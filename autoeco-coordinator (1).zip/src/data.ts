/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Startup {
  id: string;
  name: string;
  sector: 'Fintech' | 'HealthTech' | 'AI' | 'ClimateTech' | 'EdTech' | 'AgriTech';
  stage: 'Pre-seed' | 'Seed' | 'Series A' | 'Series B';
  country: string;
  needs: string[];
  verificationStatus: 'Verified' | 'Pending' | 'Rejected';
  assignedMentorId?: string;
  recommendedProgrammeId?: string;
}

export interface Mentor {
  id: string;
  name: string;
  expertise: string[];
  country: string;
  availability: 'High' | 'Medium' | 'Low';
  rating: number;
  pastSuccessRate: number;
  activeStartups: number;
}

export interface Programme {
  id: string;
  name: string;
  sector: string[];
  stage: string[];
  country: string;
  description: string;
}

export interface Partner {
  id: string;
  name: string;
  type: 'Service Provider' | 'Corporate' | 'VC';
  sector: string[];
}

export interface Relationship {
  id: string;
  startupId: string;
  targetId: string; // Mentor ID, Programme ID, or Partner ID
  targetType: 'Mentor' | 'Programme' | 'Partner';
  status: 'Active' | 'On Hold' | 'Completed';
  engagementScore: number;
  lastInteraction: string;
  meetingsCount: number;
  riskLevel: 'Healthy' | 'Needs Attention' | 'At Risk';
  nextSuggestedAction: string;
}

export interface AutomationWorkflow {
  id: string;
  name: string;
  description: string;
  status: 'Active' | 'Paused';
  lastRun: string;
  successRate: number;
  tasksCompleted: number;
}

export const initialStartups: Startup[] = [
  { id: 's1', name: 'PayFlow', sector: 'Fintech', stage: 'Seed', country: 'UK', needs: ['Fundraising', 'Market Expansion'], verificationStatus: 'Verified', assignedMentorId: 'm1' },
  { id: 's2', name: 'MediScan AI', sector: 'HealthTech', stage: 'Pre-seed', country: 'Germany', needs: ['Product Strategy', 'Legal & Compliance'], verificationStatus: 'Pending' },
  { id: 's3', name: 'NeuralOps', sector: 'AI', stage: 'Series A', country: 'USA', needs: ['Go-To-Market', 'Talent Acquisition'], verificationStatus: 'Verified', assignedMentorId: 'm2' },
  { id: 's4', name: 'CarbonZero', sector: 'ClimateTech', stage: 'Seed', country: 'Sweden', needs: ['Fundraising', 'Go-To-Market'], verificationStatus: 'Verified' },
  { id: 's5', name: 'EduQuest', sector: 'EdTech', stage: 'Seed', country: 'Canada', needs: ['Product Strategy', 'Funding'], verificationStatus: 'Pending' },
  { id: 's6', name: 'AgriSmart', sector: 'AgriTech', stage: 'Series A', country: 'Kenya', needs: ['Market Expansion', 'Market Strategy'], verificationStatus: 'Verified', assignedMentorId: 'm3' },
  { id: 's7', name: 'SafeVault', sector: 'Fintech', stage: 'Pre-seed', country: 'Singapore', needs: ['Legal & Compliance', 'Product Strategy'], verificationStatus: 'Verified' },
  { id: 's8', name: 'CleanWater.io', sector: 'ClimateTech', stage: 'Seed', country: 'Brazil', needs: ['Funding', 'GTM'], verificationStatus: 'Pending' },
];

export const initialMentors: Mentor[] = [
  { id: 'm1', name: 'Alice Chen', expertise: ['Fundraising', 'Market Expansion'], country: 'UK', availability: 'High', rating: 4.8, pastSuccessRate: 92, activeStartups: 2 },
  { id: 'm2', name: 'Bob Smith', expertise: ['AI/ML', 'Product Strategy'], country: 'USA', availability: 'Medium', rating: 4.9, pastSuccessRate: 95, activeStartups: 1 },
  { id: 'm3', name: 'Charlie David', expertise: ['Go-To-Market', 'AgriTech Specialist'], country: 'Kenya', availability: 'Low', rating: 4.7, pastSuccessRate: 88, activeStartups: 3 },
  { id: 'm4', name: 'Diana Prince', expertise: ['Legal & Compliance', 'Fintech'], country: 'Singapore', availability: 'High', rating: 4.6, pastSuccessRate: 85, activeStartups: 0 },
  { id: 'm5', name: 'Evan Wright', expertise: ['Market Strategy', 'Product Management'], country: 'USA', availability: 'Medium', rating: 4.5, pastSuccessRate: 80, activeStartups: 1 },
  { id: 'm6', name: 'Fiona Green', expertise: ['ClimateTech', 'Grant Writing'], country: 'Sweden', availability: 'High', rating: 4.9, pastSuccessRate: 98, activeStartups: 0 },
];

export const initialProgrammes: Programme[] = [
  { id: 'p1', name: 'Fintech Global Accelerator', sector: ['Fintech'], stage: ['Seed', 'Series A'], country: 'Global', description: '3-month program for high-growth fintechs.' },
  { id: 'p2', name: 'EU Health Innovators', sector: ['HealthTech'], stage: ['Pre-seed', 'Seed'], country: 'Europe', description: 'Support for health startups navigating EU compliance.' },
  { id: 'p3', name: 'AI Frontier Hub', sector: ['AI'], stage: ['Series A', 'Series B'], country: 'USA', description: 'Deep tech acceleration and partnership opportunities.' },
  { id: 'p4', name: 'Climate Impact Fund', sector: ['ClimateTech'], stage: ['Seed'], country: 'Global', description: 'Grant-based program for climate-positive innovations.' },
  { id: 'p5', name: 'Emerging Markets AgTech', sector: ['AgriTech'], stage: ['Seed', 'Series A'], country: 'Africa', description: 'Focused on scaling agritech in developing economies.' },
];

export const initialPartners: Partner[] = [
  { id: 'pa1', name: 'CloudScale VC', type: 'VC', sector: ['AI', 'Fintech'] },
  { id: 'pa2', name: 'ReguLaw Partners', type: 'Service Provider', sector: ['Legal & Compliance'] },
  { id: 'pa3', name: 'TechGlobal Corp', type: 'Corporate', sector: ['General'] },
  { id: 'pa4', name: 'EcoSeed VCs', type: 'VC', sector: ['ClimateTech'] },
];

export const initialRelationships: Relationship[] = [
  { id: 'r1', startupId: 's1', targetId: 'm1', targetType: 'Mentor', status: 'Active', engagementScore: 85, lastInteraction: '2024-05-10', meetingsCount: 5, riskLevel: 'Healthy', nextSuggestedAction: 'Schedule monthly review' },
  { id: 'r2', startupId: 's3', targetId: 'm2', targetType: 'Mentor', status: 'Active', engagementScore: 92, lastInteraction: '2024-05-12', meetingsCount: 8, riskLevel: 'Healthy', nextSuggestedAction: 'Review technical roadmap' },
  { id: 'r3', startupId: 's6', targetId: 'm3', targetType: 'Mentor', status: 'Active', engagementScore: 65, lastInteraction: '2024-04-20', meetingsCount: 3, riskLevel: 'Needs Attention', nextSuggestedAction: 'Follow up on pending tasks' },
  { id: 'r4', startupId: 's1', targetId: 'p1', targetType: 'Programme', status: 'Active', engagementScore: 78, lastInteraction: '2024-05-08', meetingsCount: 4, riskLevel: 'Healthy', nextSuggestedAction: 'Attend workshop session' },
  { id: 'r5', startupId: 's2', targetId: 'pa2', targetType: 'Partner', status: 'On Hold', engagementScore: 30, lastInteraction: '2024-03-15', meetingsCount: 1, riskLevel: 'At Risk', nextSuggestedAction: 'Re-engage for compliance check' },
  { id: 'r6', startupId: 's4', targetId: 'p4', targetType: 'Programme', status: 'Active', engagementScore: 88, lastInteraction: '2024-05-14', meetingsCount: 6, riskLevel: 'Healthy', nextSuggestedAction: 'Prepare for demo day' },
  { id: 'r7', startupId: 's7', targetId: 'pa2', targetType: 'Partner', status: 'Active', engagementScore: 75, lastInteraction: '2024-05-11', meetingsCount: 3, riskLevel: 'Healthy', nextSuggestedAction: 'Review contract drafts' },
  { id: 'r8', startupId: 's3', targetId: 'pa1', targetType: 'Partner', status: 'Active', engagementScore: 90, lastInteraction: '2024-05-15', meetingsCount: 4, riskLevel: 'Healthy', nextSuggestedAction: 'Prepare investment pitch' },
  { id: 'r9', startupId: 's5', targetId: 'p2', targetType: 'Programme', status: 'Active', engagementScore: 45, lastInteraction: '2024-04-05', meetingsCount: 2, riskLevel: 'Needs Attention', nextSuggestedAction: 'Schedule intro with program lead' },
  { id: 'r10', startupId: 's8', targetId: 'pa4', targetType: 'Partner', status: 'Active', engagementScore: 70, lastInteraction: '2024-05-05', meetingsCount: 2, riskLevel: 'Healthy', nextSuggestedAction: 'Send updated deck' },
];

export const initialWorkflows: AutomationWorkflow[] = [
  { id: 'w1', name: 'Onboarding Verification', description: 'Auto-verify startup documents and criteria.', status: 'Active', lastRun: '2024-05-15', successRate: 98, tasksCompleted: 145 },
  { id: 'w2', name: 'Mentor Matching', description: 'Identify best mentor matches for new startups.', status: 'Active', lastRun: '2024-05-16', successRate: 85, tasksCompleted: 42 },
  { id: 'w3', name: 'Meeting Reminders', description: 'Notifications for upcoming startup-mentor sessions.', status: 'Active', lastRun: '2024-05-16', successRate: 99, tasksCompleted: 890 },
  { id: 'w4', name: 'Monthly Progress Check', description: 'Automated surveys and KPIs collection.', status: 'Paused', lastRun: '2024-05-01', successRate: 72, tasksCompleted: 56 },
  { id: 'w5', name: 'Engagement Risk Detection', description: 'Analyze scores to flag low activity relationships.', status: 'Active', lastRun: '2024-05-16', successRate: 91, tasksCompleted: 28 },
];
