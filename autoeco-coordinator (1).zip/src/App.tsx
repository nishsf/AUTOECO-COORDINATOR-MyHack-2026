/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Rocket, 
  Users, 
  Cpu, 
  Zap, 
  BarChart3, 
  MessageSquare, 
  Settings, 
  Map, 
  Activity,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  Search,
  Bell,
  Menu,
  X,
  ChevronRight,
  Filter,
  Plus,
  Play,
  RotateCcw,
  Sparkles,
  Link2,
  TrendingUp,
  BrainCircuit,
  Award
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { 
  initialStartups, 
  initialMentors, 
  initialProgrammes, 
  initialPartners, 
  initialRelationships, 
  initialWorkflows,
  type Startup,
  type Mentor,
  type Programme,
  type Partner,
  type Relationship,
  type AutomationWorkflow
} from './data';
import { useAuth } from './AuthProvider';
import { Login } from './components/Login';
import { LogOut, ShieldAlert } from 'lucide-react';

// Utility for Tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  icon?: any;
  key?: React.Key;
}

const Card = ({ children, className, title, subtitle, icon: Icon }: CardProps) => (
  <div className={cn("bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden transition-all hover:shadow-md", className)}>
    {(title || Icon) && (
      <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
        <div>
          {title && <h3 className="font-bold text-slate-800 tracking-tight">{title}</h3>}
          {subtitle && <p className="text-[10px] uppercase font-bold text-slate-400 mt-1 tracking-wider">{subtitle}</p>}
        </div>
        {Icon && <div className="p-2 bg-slate-50 rounded-lg"><Icon className="w-4 h-4 text-slate-400" /></div>}
      </div>
    )}
    <div className="p-6">{children}</div>
  </div>
);

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info';
  key?: React.Key;
}

const Badge = ({ children, variant = 'default' }: BadgeProps) => {
  const variants = {
    default: "bg-slate-100 text-slate-700",
    success: "bg-emerald-50 text-emerald-700 border border-emerald-100",
    warning: "bg-amber-50 text-amber-700 border border-amber-100",
    error: "bg-rose-50 text-rose-700 border border-rose-100",
    info: "bg-indigo-50 text-indigo-700 border border-indigo-100",
  };
  return (
    <span className={cn("px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider", variants[variant])}>
      {children}
    </span>
  );
};

const StatCard = ({ title, value, subValue, icon: Icon, trend }: { title: string, value: string | number, subValue?: string, icon: any, trend?: { value: number, isUp: boolean } }) => (
  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
    <div className="w-12 h-12 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center text-slate-600 shrink-0">
      <Icon className="w-6 h-6" />
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest truncate">{title}</p>
      <div className="flex items-baseline gap-2">
        <h3 className="text-2xl font-black text-slate-900 tracking-tight">{value}</h3>
        {trend && (
          <span className={cn("text-[10px] font-bold", trend.isUp ? "text-emerald-600" : "text-rose-600")}>
            {trend.isUp ? '+' : '-'}{trend.value}%
          </span>
        )}
      </div>
      {subValue && <p className="text-[10px] font-medium text-slate-400 mt-0.5 truncate">{subValue}</p>}
    </div>
  </div>
);

const Notification = ({ message, type = 'success' }: { message: string, type?: 'success' | 'info' }) => (
  <motion.div 
    initial={{ opacity: 0, y: 50 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, scale: 0.95 }}
    className={cn(
      "fixed bottom-6 right-6 px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 z-50 border",
      type === 'success' ? "bg-slate-900 text-white border-slate-800" : "bg-white text-slate-900 border-slate-200"
    )}
  >
    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", type === 'success' ? "bg-emerald-500/20 text-emerald-400" : "bg-indigo-50 text-indigo-600")}>
      {type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
    </div>
    <span className="text-xs font-bold tracking-tight">{message}</span>
  </motion.div>
);

// --- Main App ---

type Page = 'dashboard' | 'startups' | 'mentors' | 'matching' | 'programmes' | 'automation' | 'relationships' | 'engagement' | 'reports';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function App() {
  const { user, loading, isAdmin, logout } = useAuth();
  const [activePage, setActivePage] = useState<Page>('dashboard');
  const [startups, setStartups] = useState<Startup[]>(initialStartups);
  const [mentors, setMentors] = useState<Mentor[]>(initialMentors);
  const [programmes] = useState<Programme[]>(initialProgrammes);
  const [partners] = useState<Partner[]>(initialPartners);
  const [relationships, setRelationships] = useState<Relationship[]>(initialRelationships);
  const [workflows, setWorkflows] = useState<AutomationWorkflow[]>(initialWorkflows);
  const [notification, setNotification] = useState<{ message: string, type: 'success' | 'info' } | null>(null);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [matchingStartupId, setMatchingStartupId] = useState<string | null>(null);
  const [isMatchingLoading, setIsMatchingLoading] = useState(false);
  
  // Copilot State
  const [copilotMessages, setCopilotMessages] = useState<Message[]>([
    { role: 'assistant', content: 'System initialized. I am monitoring 8 startups and 6 mentors. Signal strength optimal. How can I assist with ecosystem coordination?' }
  ]);
  const [copilotInput, setCopilotInput] = useState('');
  const [isCopilotLoading, setIsCopilotLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [copilotMessages]);

  // --- Actions ---
  const notify = (message: string, type: 'success' | 'info' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleCopilotSend = async () => {
    if (!copilotInput.trim() || isCopilotLoading) return;

    const userMessage = copilotInput.trim();
    setCopilotInput('');
    setCopilotMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsCopilotLoading(true);

    try {
      const response = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          context: {
            startups,
            mentors,
            relationships,
          }
        }),
      });

      if (!response.ok) throw new Error('Failed to connect to Neural Link');

      const data = await response.json();
      setCopilotMessages(prev => [...prev, { role: 'assistant', content: data.text }]);
    } catch (error) {
      console.error('Copilot Error:', error);
      setCopilotMessages(prev => [...prev, { role: 'assistant', content: 'Error: Connection to Neural Link interrupted. Please verify GEMINI_API_KEY is configured.' }]);
    } finally {
      setIsCopilotLoading(false);
    }
  };

  const handleVerifyStartup = (id: string) => {
    setStartups(prev => prev.map(s => s.id === id ? { ...s, verificationStatus: 'Verified' } : s));
    notify("Startup successfully verified");
  };

  const handleRunAutomation = (id: string) => {
    setWorkflows(prev => prev.map(w => w.id === id ? { 
      ...w, 
      lastRun: new Date().toISOString().split('T')[0], 
      tasksCompleted: w.tasksCompleted + Math.floor(Math.random() * 5) + 1 
    } : w));
    notify("Automation workflow processed", "info");
  };

  const handleApproveMatch = (startupId: string, mentorId: string) => {
    const startup = startups.find(s => s.id === startupId);
    const mentor = mentors.find(m => m.id === mentorId);
    if (!startup || !mentor) return;

    setStartups(prev => prev.map(s => s.id === startupId ? { ...s, assignedMentorId: mentorId } : s));
    
    const newRelation: Relationship = {
      id: `r${Date.now()}`,
      startupId,
      targetId: mentorId,
      targetType: 'Mentor',
      status: 'Active',
      engagementScore: 70,
      lastInteraction: new Date().toISOString().split('T')[0],
      meetingsCount: 0,
      riskLevel: 'Healthy',
      nextSuggestedAction: 'Schedule intro session'
    };
    
    setRelationships(prev => [...prev, newRelation]);
    setMatchingStartupId(null);
    notify(`Matched ${startup.name} with ${mentor.name}`);
  };

  // --- Derived State ---
  const stats = useMemo(() => {
    return {
      totalStartups: startups.length,
      totalMentors: mentors.length,
      pendingMatches: startups.filter(s => !s.assignedMentorId).length,
      activeRelationships: relationships.filter(r => r.status === 'Active').length,
      avgEngagement: Math.round(relationships.reduce((acc, r) => acc + r.engagementScore, 0) / (relationships.length || 1)),
      tasksCompleted: workflows.reduce((acc, w) => acc + w.tasksCompleted, 0),
    };
  }, [startups, mentors, relationships, workflows]);

  const sectorData = useMemo(() => {
    const counts: Record<string, number> = {};
    startups.forEach(s => counts[s.sector] = (counts[s.sector] || 0) + 1);
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [startups]);

  const engagementTrend = [
    { name: 'Jan', score: 65 },
    { name: 'Feb', score: 68 },
    { name: 'Mar', score: 72 },
    { name: 'Apr', score: 70 },
    { name: 'May', score: 75 },
  ];

  // --- Navigation ---
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'startups', label: 'Startups', icon: Rocket },
    { id: 'mentors', label: 'Mentors', icon: Users },
    { id: 'matching', label: 'AI Matching', icon: BrainCircuit },
    { id: 'programmes', label: 'Programmes', icon: Award },
    { id: 'automation', label: 'Automation', icon: Zap },
    { id: 'relationships', label: 'Ecosystem Map', icon: Map },
    { id: 'engagement', label: 'Engagement', icon: Activity },
    { id: 'reports', label: 'Insights', icon: BarChart3 },
  ];

  if (loading) {
    return (
      <div className="h-screen bg-slate-900 flex flex-col items-center justify-center gap-6">
        <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-2xl animate-pulse">
          <BrainCircuit className="w-8 h-8" />
        </div>
        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Synching Neural Data...</p>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-200 p-10 text-center space-y-6">
          <div className="w-20 h-20 bg-rose-50 rounded-3xl mx-auto flex items-center justify-center text-rose-600 border border-rose-100">
            <ShieldAlert className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Access Denied</h2>
            <p className="text-sm text-slate-500 font-medium">Your account ({user.email}) does not have administrative permissions for this ecosystem node.</p>
          </div>
          <button 
            onClick={() => logout()}
            className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold text-sm hover:bg-black transition shadow-lg"
          >
            Sign Out & Try Another Account
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col z-20 shadow-2xl">
        <div className="p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-black text-xl tracking-tighter uppercase leading-none">AutoEco</h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-1">Ecosystem</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1 mt-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id as Page)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group",
                activePage === item.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 font-bold" 
                  : "text-slate-400 hover:bg-slate-800/50 hover:text-white"
              )}
            >
              <item.icon className={cn("w-5 h-5", activePage === item.id ? "text-white" : "text-slate-500 group-hover:text-indigo-400")} />
              <span className="text-sm tracking-tight">{item.label}</span>
              {activePage === item.id && (
                <motion.div layoutId="active-indicator" className="ml-auto w-1 h-4 bg-indigo-200 rounded-full" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-slate-800">
          <div className="bg-indigo-950/50 border border-indigo-900 rounded-2xl p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-indigo-400">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-widest">Co-Pilot Node</span>
            </div>
            <p className="text-[11px] text-indigo-200/80 leading-relaxed font-medium">9 active automated agents are monitoring your hub.</p>
            <button 
              onClick={() => setIsCopilotOpen(true)}
              className="w-full bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest py-3 rounded-xl hover:bg-indigo-500 transition shadow-lg shadow-indigo-600/20"
            >
              Command Unit
            </button>
          </div>
        </div>
      </aside>

      {/* Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="h-16 border-b border-slate-200 bg-white/90 backdrop-blur-md px-8 flex items-center justify-between z-10 shrink-0">
          <div className="flex items-center gap-4 flex-1">
            <div className="relative max-w-md w-full">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Query ecosystem database..." 
                className="w-full bg-slate-50 border-none rounded-xl py-2 pl-10 pr-4 text-xs font-semibold text-slate-600 focus:ring-2 focus:ring-indigo-100 transition"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-400 hover:text-gray-900 transition relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
            </button>
            <div className="h-8 w-px bg-gray-200 mx-2" />
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-bold text-gray-900 leading-none truncate max-w-[150px]">{user.displayName || 'Coordinator'}</p>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-1 truncate max-w-[150px]">{user.email}</p>
              </div>
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center border-2 border-white shadow-sm overflow-hidden">
                <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} alt="avatar" />
              </div>
              <button 
                onClick={() => logout()}
                className="p-2 bg-slate-50 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl transition-all border border-slate-100"
                title="Log Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* Dynamic Page Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          <AnimatePresence mode="wait">
            {activePage === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                    <div className="flex items-end justify-between">
                  <div>
                    <h2 className="text-3xl font-black tracking-tight text-slate-900 uppercase">Ecosystem Pulse</h2>
                    <p className="text-slate-500 mt-1 font-medium">Real-time status of your innovation programme.</p>
                  </div>
                  <div className="flex gap-3">
                    <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition shadow-sm uppercase tracking-wider">Export Analytics</button>
                    <button className="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-black shadow-lg shadow-slate-200 transition uppercase tracking-widest">Add Entity</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  <StatCard title="Total Startups" value={stats.totalStartups} subValue="8 high-growth companies" icon={Rocket} trend={{ value: 12, isUp: true }} />
                  <StatCard title="Mentor Network" value={stats.totalMentors} subValue="Active across 4 regions" icon={Users} trend={{ value: 5, isUp: true }} />
                  <StatCard title="Active Relationships" value={stats.activeRelationships} subValue="Mentors, Partners, Programs" icon={Map} trend={{ value: 24, isUp: true }} />
                  <StatCard title="Engagement Score" value={`${stats.avgEngagement}%`} subValue="Avg. satisfaction score" icon={Activity} trend={{ value: 8, isUp: true }} />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <Card className="lg:col-span-2" title="Engagement Level Trends" icon={TrendingUp}>
                    <div className="h-72 w-full pt-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={engagementTrend}>
                          <defs>
                            <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                              <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }} dy={10} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }} dx={-10} domain={[0, 100]} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                          />
                          <Area type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </Card>
                  
                  <Card title="Sector Distribution" icon={Filter}>
                    <div className="h-72 w-full flex flex-col items-center justify-center">
                      <ResponsiveContainer width="100%" height="80%">
                        <PieChart>
                          <Pie
                            data={sectorData}
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                            strokeWidth={0}
                          >
                            {sectorData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={['#1e293b', '#334155', '#475569', '#64748b', '#94a3b8', '#cbd5e1'][index % 6]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="grid grid-cols-2 gap-x-6 gap-y-2 mt-4 text-[10px] w-full px-4">
                        {sectorData.map((entry, index) => (
                          <div key={entry.name} className="flex items-center gap-2">
                             <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ['#1e293b', '#334155', '#475569', '#64748b', '#94a3b8', '#cbd5e1'][index % 6] }} />
                             <span className="font-medium text-gray-500 truncate">{entry.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Card>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card title="System Alerts" icon={AlertCircle}>
                    <div className="space-y-4">
                      {relationships.filter(r => r.riskLevel !== 'Healthy').map(r => (
                        <div key={r.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition cursor-default group">
                          <div className={cn(
                            "w-10 h-10 rounded-full flex items-center justify-center",
                            r.riskLevel === 'At Risk' ? "bg-rose-100 text-rose-600" : "bg-amber-100 text-amber-600"
                          )}>
                            <AlertCircle className="w-5 h-5" />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-sm font-bold">{startups.find(s => s.id === r.startupId)?.name}</h4>
                            <p className="text-xs text-gray-500">Relationship with {r.targetType} is {r.riskLevel.toLowerCase()}</p>
                          </div>
                          <button className="text-[10px] font-bold text-blue-600 uppercase tracking-wider opacity-0 group-hover:opacity-100 transition">Fix Issue</button>
                        </div>
                      ))}
                    </div>
                  </Card>

                  <Card title="Recent AI Actions" icon={BrainCircuit}>
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 shrink-0" />
                        <div>
                          <p className="text-sm text-gray-600">Generated matching score for <span className="font-bold text-gray-900">NeuralOps</span></p>
                          <p className="text-[10px] text-gray-400 mt-1 uppercase font-bold">2 minutes ago</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 mt-2 shrink-0" />
                        <div>
                          <p className="text-sm text-gray-600">Auto-verified <span className="font-bold text-gray-900">PayFlow</span> documents</p>
                          <p className="text-[10px] text-gray-400 mt-1 uppercase font-bold">1 hour ago</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4">
                        <div className="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0" />
                        <div>
                          <p className="text-sm text-gray-600">Sent risk alert for <span className="font-bold text-gray-900">MediScan</span> partnership</p>
                          <p className="text-[10px] text-gray-400 mt-1 uppercase font-bold">3 hours ago</p>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              </motion.div>
            )}

            {activePage === 'startups' && (
              <motion.div 
                key="startups"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-end justify-between">
                  <div>
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">Startup Portfolio</h2>
                    <p className="text-gray-500 mt-1">Manage and verify participants in your programme.</p>
                  </div>
                  <button className="px-6 py-2.5 bg-gray-900 text-white rounded-xl text-sm font-bold shadow-lg shadow-gray-200 hover:bg-black transition flex items-center gap-2">
                    <Plus className="w-4 h-4" /> Import CSV
                  </button>
                </div>

                <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-100 text-[10px] uppercase tracking-widest font-bold text-gray-400">
                          <th className="px-6 py-4">Startup</th>
                          <th className="px-6 py-4">Sector & Stage</th>
                          <th className="px-6 py-4">Country</th>
                          <th className="px-6 py-4">Status</th>
                          <th className="px-6 py-4">Mentor</th>
                          <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {startups.map((s) => (
                          <tr key={s.id} className="hover:bg-gray-50/50 transition">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center text-white font-bold text-xs">
                                  {s.name[0]}
                                </div>
                                <div>
                                  <p className="font-bold text-gray-900 text-sm">{s.name}</p>
                                  <p className="text-xs text-gray-500">ID: {s.id.toUpperCase()}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="space-y-1">
                                <Badge variant="info">{s.sector}</Badge>
                                <p className="text-xs text-gray-400 font-medium">{s.stage}</p>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-gray-600">{s.country}</td>
                            <td className="px-6 py-4">
                              <Badge variant={s.verificationStatus === 'Verified' ? 'success' : s.verificationStatus === 'Pending' ? 'warning' : 'error'}>
                                {s.verificationStatus}
                              </Badge>
                            </td>
                            <td className="px-6 py-4">
                              {s.assignedMentorId ? (
                                <div className="flex items-center gap-2">
                                  <div className="w-6 h-6 rounded-full bg-gray-100 overflow-hidden">
                                     <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${mentors.find(m => m.id === s.assignedMentorId)?.name}`} alt="mentor" />
                                  </div>
                                  <span className="text-xs font-semibold">{mentors.find(m => m.id === s.assignedMentorId)?.name}</span>
                                </div>
                              ) : (
                                <button className="text-[10px] font-bold text-blue-600 flex items-center gap-1 hover:underline">
                                  <BrainCircuit className="w-3 h-3" /> Auto Match
                                </button>
                              )}
                            </td>
                            <td className="px-6 py-4 text-right space-x-2">
                              {s.verificationStatus === 'Pending' && (
                                <button 
                                  onClick={() => handleVerifyStartup(s.id)}
                                  className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest hover:bg-emerald-50 px-2 py-1 rounded"
                                >
                                  Verify
                                </button>
                              )}
                              <button className="text-[10px] font-bold text-gray-500 uppercase tracking-widest hover:bg-gray-100 px-2 py-1 rounded">Profile</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {activePage === 'mentors' && (
              <motion.div 
                key="mentors"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="flex items-end justify-between">
                  <div>
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">Expert Network</h2>
                    <p className="text-gray-500 mt-1">Our curated pool of global mentors and specialists.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {mentors.map((m) => (
                    <Card key={m.id} className="relative group">
                      <div className="flex items-start justify-between">
                        <div className="flex gap-4">
                          <div className="w-16 h-16 rounded-2xl bg-gray-50 overflow-hidden border border-gray-100 shrink-0 shadow-inner">
                            <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${m.name}`} alt={m.name} />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">{m.name}</h3>
                            <p className="text-xs text-gray-500">{m.country}</p>
                            <div className="mt-2 flex flex-wrap gap-1">
                              {m.expertise.slice(0, 2).map((exp, i) => (
                                <Badge key={i} variant="info">{exp}</Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <Badge variant={m.availability === 'High' ? 'success' : m.availability === 'Medium' ? 'warning' : 'error'}>
                          {m.availability}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-gray-50">
                        <div className="text-center">
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Rating</p>
                          <p className="text-sm font-bold text-gray-900 mt-1 flex items-center justify-center gap-1">
                            <Award className="w-3 h-3 text-amber-500" /> {m.rating}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Success</p>
                          <p className="text-sm font-bold text-gray-900 mt-1">{m.pastSuccessRate}%</p>
                        </div>
                        <div className="text-center">
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Active</p>
                          <p className="text-sm font-bold text-gray-900 mt-1">{m.activeStartups}</p>
                        </div>
                      </div>

                      <div className="mt-6 flex gap-2">
                        <button className="flex-1 bg-gray-50 text-gray-900 text-xs font-bold py-2.5 rounded-xl hover:bg-gray-100 transition">View CV</button>
                        <button className="flex-1 bg-gray-900 text-white text-xs font-bold py-2.5 rounded-xl hover:bg-black transition">Match Now</button>
                      </div>
                    </Card>
                  ))}
                </div>
              </motion.div>
            )}

            {activePage === 'matching' && (
              <motion.div 
                key="matching"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 bg-blue-50 rounded-3xl mx-auto flex items-center justify-center text-blue-600 shadow-inner">
                    <BrainCircuit className="w-10 h-10" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold tracking-tight">AI Matching Engine</h2>
                    <p className="text-gray-500 max-w-lg mx-auto">Automated mentor and programme pairing based on 24-point ecosystem vectors.</p>
                  </div>
                </div>

                <div className="bg-white rounded-3xl border border-gray-200 p-8 shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
                  
                  <div className="space-y-6">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1">Select Target Startup</label>
                      <select 
                        className="w-full mt-2 bg-gray-50 border-none rounded-2xl py-4 px-6 font-bold text-gray-900 focus:ring-2 focus:ring-blue-500 transition appearance-none cursor-pointer"
                        value={matchingStartupId || ''}
                        onChange={(e) => setMatchingStartupId(e.target.value)}
                      >
                        <option value="">Choose a startup waiting for a match...</option>
                        {startups.filter(s => !s.assignedMentorId).map(s => (
                          <option key={s.id} value={s.id}>{s.name} ({s.sector})</option>
                        ))}
                      </select>
                    </div>

                    <button 
                      disabled={!matchingStartupId || isMatchingLoading}
                      onClick={() => {
                        setIsMatchingLoading(true);
                        setTimeout(() => setIsMatchingLoading(false), 2000);
                      }}
                      className={cn(
                        "w-full py-5 rounded-2xl flex items-center justify-center gap-3 font-bold transition-all shadow-xl",
                        (!matchingStartupId || isMatchingLoading) 
                          ? "bg-gray-100 text-gray-400" 
                          : "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-200"
                      )}
                    >
                      {isMatchingLoading ? (
                        <>
                          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }} className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full" />
                          Analyzing Ecosystem Data...
                        </>
                      ) : (
                        <>
                          <Zap className="w-5 h-5 fill-current" />
                          Run AI Recommendation Engine
                        </>
                      )}
                    </button>
                  </div>

                  <AnimatePresence>
                    {!isMatchingLoading && matchingStartupId && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-12 space-y-6"
                      >
                        <div className="flex items-center gap-2 mb-4">
                          <Badge variant="info">Top 3 Recommended Mentors</Badge>
                          <span className="text-[10px] text-gray-400 font-bold uppercase">Vectors matched: sector, goal, region</span>
                        </div>

                        {mentors.slice(0, 3).map((m, i) => (
                          <motion.div 
                            key={m.id}
                            initial={{ x: -20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: i * 0.1 }}
                            className="p-6 border border-gray-100 rounded-2xl bg-gray-50/50 flex items-center gap-6 hover:border-blue-200 transition group"
                          >
                            <div className="text-2xl font-black text-gray-200 shrink-0 w-8">{i + 1}</div>
                            <div className="w-14 h-14 rounded-2xl bg-white shadow-sm overflow-hidden border border-white">
                              <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${m.name}`} alt={m.name} />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-900">{m.name}</h4>
                              <p className="text-xs text-blue-600 font-bold mt-0.5">Matching Score: {98 - (i * 4)}%</p>
                              <p className="text-[10px] text-gray-500 mt-2 leading-relaxed">Highly expertise in <span className="font-bold">{m.expertise[0]}</span> which matches the startup's current focus on fundraising and expansion.</p>
                            </div>
                            <button 
                              onClick={() => handleApproveMatch(matchingStartupId!, m.id)}
                              className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-xs font-bold hover:bg-gray-900 hover:text-white transition group-hover:border-transparent group-hover:shadow-md"
                            >
                              Approve Match
                            </button>
                          </motion.div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}

            {activePage === 'programmes' && (
              <motion.div 
                key="programmes"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                <div className="flex items-end justify-between">
                  <div>
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">Innovation Hubs</h2>
                    <p className="text-gray-500 mt-1">Available programmes and focus areas in your network.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {initialProgrammes.map((p) => (
                    <Card key={p.id} className="group hover:border-blue-400 transition-colors">
                      <div className="flex items-start gap-6">
                        <div className="w-20 h-20 bg-gray-900 rounded-3xl flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-300">
                          <Award className="w-10 h-10" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-xl font-bold text-gray-900 leading-none">{p.name}</h3>
                              <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-2">{p.country}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-1 rounded">Open for Enrollment</p>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mt-4 leading-relaxed">{p.description}</p>
                          <div className="mt-4 flex flex-wrap gap-2">
                             {p.sector.map(s => <Badge key={s} variant="info">{s}</Badge>)}
                             {p.stage.map(s => <Badge key={s}>{s}</Badge>)}
                          </div>
                        </div>
                      </div>
                      <div className="mt-6 pt-6 border-t border-gray-50 flex items-center justify-between">
                        <div className="flex -space-x-2">
                          {[1,2,3].map(i => (
                            <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-100 overflow-hidden ring-1 ring-gray-100">
                              <img src={`https://api.dicebear.com/7.x/initials/svg?seed=P${i}`} alt="p" />
                            </div>
                          ))}
                          <div className="w-8 h-8 rounded-full border-2 border-white bg-gray-900 flex items-center justify-center text-[10px] font-bold text-white ring-1 ring-gray-100">
                            +12
                          </div>
                        </div>
                        <button className="px-5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition">Recommend Program</button>
                      </div>
                    </Card>
                  ))}
                </div>
              </motion.div>
            )}

            {activePage === 'automation' && (
              <motion.div 
                key="automation"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-3xl font-bold tracking-tight text-gray-900">Automation Center</h2>
                  <p className="text-gray-500 mt-1">Autonomous workflows managing the routine coordination.</p>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  {workflows.map((w) => (
                    <div key={w.id} className="bg-white border border-gray-200 rounded-3xl p-8 shadow-sm flex flex-col justify-between group h-full">
                      <div className="flex items-start justify-between">
                        <div className="flex gap-5">
                          <div className={cn(
                            "w-14 h-14 rounded-2xl flex items-center justify-center shrink-0",
                            w.status === 'Active' ? "bg-blue-50 text-blue-600" : "bg-gray-100 text-gray-400"
                          )}>
                            {w.id === 'w1' && <CheckCircle2 className="w-7 h-7" />}
                            {w.id === 'w2' && <BrainCircuit className="w-7 h-7" />}
                            {w.id === 'w3' && <Clock className="w-7 h-7" />}
                            {w.id === 'w4' && <RotateCcw className="w-7 h-7" />}
                            {w.id === 'w5' && <Zap className="w-7 h-7" />}
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-gray-900">{w.name}</h3>
                            <p className="text-sm text-gray-500 mt-1">{w.description}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                           <div className={cn(
                             "w-12 h-6 rounded-full relative transition-colors duration-300 cursor-pointer",
                             w.status === 'Active' ? "bg-emerald-500" : "bg-gray-200"
                           )}>
                             <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 shadow-sm", w.status === 'Active' ? "right-1" : "left-1")} />
                           </div>
                           <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{w.status}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-6 mt-10 pt-8 border-t border-gray-50">
                        <div>
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Last Run</p>
                          <p className="text-sm font-bold text-gray-900 mt-1">{w.lastRun}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Success Rate</p>
                          <p className="text-sm font-bold text-emerald-600 mt-1">{w.successRate}%</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Tasks Done</p>
                          <p className="text-sm font-bold text-gray-900 mt-1">{w.tasksCompleted}</p>
                        </div>
                      </div>

                      <button 
                         onClick={() => handleRunAutomation(w.id)}
                         className="w-full mt-8 py-3 bg-gray-50 text-gray-900 rounded-2xl text-xs font-bold hover:bg-gray-900 hover:text-white transition-all flex items-center justify-center gap-2"
                      >
                        <Play className="w-3 h-3 fill-current" /> Run Workflow
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activePage === 'relationships' && (
              <motion.div 
                key="relationships"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                 <div>
                  <h2 className="text-3xl font-bold tracking-tight text-gray-900">Ecosystem Map</h2>
                  <p className="text-gray-500 mt-1">Holistic view of all active connections in your innovation hub.</p>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-3xl p-10 min-h-[600px] relative overflow-hidden shadow-sm">
                   {/* This is a visual representation of nodes - simplified for prototype */}
                   <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
                   
                   <div className="relative h-full flex flex-wrap gap-8 items-center justify-center">
                     {relationships.slice(0, 8).map((r, i) => {
                       const startup = startups.find(s => s.id === r.startupId);
                       return (
                         <motion.div 
                           key={r.id}
                           initial={{ scale: 0.9, opacity: 0 }}
                           animate={{ scale: 1, opacity: 1 }}
                           transition={{ delay: i * 0.05 }}
                           className="bg-white rounded-2xl p-6 shadow-xl border border-gray-100 w-64 group hover:ring-2 hover:ring-blue-500 transition-all cursor-pointer"
                         >
                           <div className="flex items-center gap-3 mb-4">
                             <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center text-white text-xs font-bold">
                               {startup?.name[0]}
                             </div>
                             <div className="w-6 h-px bg-gray-200" />
                             <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 border border-blue-100">
                               {r.targetType === 'Mentor' ? <Users className="w-4 h-4" /> : <Award className="w-4 h-4" />}
                             </div>
                           </div>
                           
                           <h4 className="font-bold text-gray-900 text-sm truncate">{startup?.name} &rarr; {r.targetType}</h4>
                           <div className="flex items-center gap-2 mt-2">
                             <Badge variant={r.status === 'Active' ? 'success' : 'warning'}>{r.status}</Badge>
                             <span className="text-[10px] font-bold text-gray-400">{r.engagementScore}% Health</span>
                           </div>
                           
                           <div className="mt-4 pt-4 border-t border-gray-50 space-y-2">
                             <p className="text-[10px] text-gray-400 font-bold uppercase">Next Action</p>
                             <p className="text-[11px] font-medium text-gray-600 flex items-center gap-1">
                               <ArrowRight className="w-3 h-3 text-blue-500" /> {r.nextSuggestedAction}
                             </p>
                           </div>
                         </motion.div>
                       );
                     })}
                   </div>
                </div>
              </motion.div>
            )}

            {activePage === 'engagement' && (
              <motion.div 
                key="engagement"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-3xl font-bold tracking-tight text-gray-900">Engagement Tracker</h2>
                  <p className="text-gray-500 mt-1">Detailed activity monitoring and risk assessment.</p>
                </div>

                <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                        <th className="px-6 py-4">Startup</th>
                        <th className="px-6 py-4">Facilitator</th>
                        <th className="px-6 py-4">Meetings</th>
                        <th className="px-6 py-4">Engagement</th>
                        <th className="px-6 py-4">Risk Level</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {relationships.map((r) => {
                        const startup = startups.find(s => s.id === r.startupId);
                        const facilitatorName = r.targetType === 'Mentor' 
                          ? mentors.find(m => m.id === r.targetId)?.name 
                          : programmes.find(p => p.id === r.targetId)?.name || partners.find(pa => pa.id === r.targetId)?.name;
                        
                        return (
                          <tr key={r.id} className="hover:bg-gray-50/50 transition">
                            <td className="px-6 py-4">
                              <span className="font-bold text-gray-900 text-sm">{startup?.name}</span>
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-gray-600">{facilitatorName}</td>
                            <td className="px-6 py-4">
                               <div className="flex items-center gap-2">
                                <span className="text-sm font-bold text-gray-900">{r.meetingsCount}</span>
                                <div className="flex gap-0.5">
                                  {[1,2,3,4,5].map(i => (
                                    <div key={i} className={cn("w-1 h-3 rounded-full", i <= r.meetingsCount % 6 ? "bg-blue-500" : "bg-gray-100")} />
                                  ))}
                                </div>
                               </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden max-w-[80px]">
                                <div 
                                  className={cn(
                                    "h-full rounded-full transition-all duration-500",
                                    r.engagementScore > 80 ? "bg-emerald-500" : r.engagementScore > 60 ? "bg-blue-500" : "bg-rose-500"
                                  )}
                                  style={{ width: `${r.engagementScore}%` }}
                                />
                              </div>
                              <span className="text-[10px] font-bold text-gray-400 mt-1 block">{r.engagementScore}% Intensity</span>
                            </td>
                            <td className="px-6 py-4">
                              <Badge variant={r.riskLevel === 'Healthy' ? 'success' : r.riskLevel === 'Needs Attention' ? 'warning' : 'error'}>
                                {r.riskLevel}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button className="text-[10px] font-bold text-blue-600 uppercase tracking-widest hover:underline">Re-Engage</button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activePage === 'reports' && (
              <motion.div 
                key="reports"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-8"
              >
                <div>
                  <h2 className="text-3xl font-bold tracking-tight text-gray-900">Ecosystem Insights</h2>
                  <p className="text-gray-500 mt-1">Aggregate performance and growth metrics.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card title="Activity Comparison by Facilitator Type" icon={BarChart3}>
                    <div className="h-64 w-full pt-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { type: 'Mentor', value: 45 },
                          { type: 'VC', value: 32 },
                          { type: 'Corporate', value: 18 },
                          { type: 'Program', value: 55 },
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="type" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} dy={10} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} dx={-10} />
                          <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                          <Bar dataKey="value" fill="#4f46e5" radius={[6, 6, 0, 0]} barSize={40} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </Card>

                  <Card title="Engagement Risk Heatmap" icon={AlertCircle}>
                    <div className="space-y-4 pt-2">
                       <div className="flex justify-between items-center text-xs text-gray-500 mb-1 font-bold">
                         <span>Startup Health Distribution</span>
                         <span>Avg 78%</span>
                       </div>
                       <div className="h-8 w-full flex rounded-xl overflow-hidden border border-gray-100">
                          <div className="bg-emerald-500 h-full border-r border-white/20" style={{ width: '65%' }} />
                          <div className="bg-amber-500 h-full border-r border-white/20" style={{ width: '25%' }} />
                          <div className="bg-rose-500 h-full" style={{ width: '10%' }} />
                       </div>
                       <div className="flex gap-4 mt-2">
                         <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500" /><span className="text-[10px] font-bold text-gray-500 uppercase">Healthy (65%)</span></div>
                         <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-amber-500" /><span className="text-[10px] font-bold text-gray-500 uppercase">Attention (25%)</span></div>
                         <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-rose-500" /><span className="text-[10px] font-bold text-gray-500 uppercase">At Risk (10%)</span></div>
                       </div>

                       <div className="mt-8 space-y-3">
                          <h4 className="text-sm font-bold">Priority Recommendations</h4>
                          <div className="p-3 bg-blue-50 rounded-xl border border-blue-100 flex items-start gap-3">
                             <Sparkles className="w-4 h-4 text-blue-600 mt-0.5" />
                             <p className="text-xs text-blue-700 font-medium leading-relaxed">Consider re-assigning <span className="font-black">MediScan AI</span> to a local mentor in Germany to improve compliance engagement score.</p>
                          </div>
                          <div className="p-3 bg-amber-50 rounded-xl border border-amber-100 flex items-start gap-3">
                             <Zap className="w-4 h-4 text-amber-600 mt-0.5" />
                             <p className="text-xs text-amber-700 font-medium leading-relaxed">Monthly progress checks for <span className="font-black">AgriTech</span> cohort have been paused for too long.</p>
                          </div>
                       </div>
                    </div>
                  </Card>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* AI Copilot Panel */}
      <AnimatePresence>
        {isCopilotOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCopilotOpen(false)}
              className="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-40"
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-96 bg-white shadow-2xl z-50 flex flex-col border-l border-slate-200"
            >
              <div className="p-6 border-b border-indigo-500/10 flex items-center justify-between bg-slate-900 text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                    <BrainCircuit className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold tracking-tight">AI Copilot</h3>
                    <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-1">
                      <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
                      Protocol Active
                    </div>
                  </div>
                </div>
                <button onClick={() => setIsCopilotOpen(false)} className="p-2 hover:bg-white/10 rounded-lg transition">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30">
                <div className="space-y-4">
                  {copilotMessages.map((msg, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={cn(
                        "p-4 rounded-2xl max-w-[90%] shadow-sm text-xs leading-relaxed",
                        msg.role === 'assistant' 
                          ? "bg-white border border-slate-200 rounded-tl-none text-slate-600 italic" 
                          : "bg-indigo-600 text-white ml-auto rounded-tr-none font-medium not-italic"
                      )}
                    >
                      {msg.content}
                    </motion.div>
                  ))}
                  {isCopilotLoading && (
                    <div className="flex gap-2 p-4">
                      <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0 }} className="w-1.5 h-1.5 bg-indigo-400 rounded-full" />
                      <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }} className="w-1.5 h-1.5 bg-indigo-400 rounded-full" />
                      <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }} className="w-1.5 h-1.5 bg-indigo-400 rounded-full" />
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                  
                  <div className="space-y-2">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Tactical Shortcuts</p>
                    <div className="flex flex-wrap gap-2">
                      {['Find Fintech mentors', 'Identify high-risk startups', 'Show AI sector growth'].map((q) => (
                        <button 
                          key={q} 
                          onClick={() => setCopilotInput(q)}
                          className="bg-white border border-slate-200 px-3 py-2 rounded-xl text-[10px] font-bold text-slate-600 hover:border-indigo-500 hover:text-indigo-600 transition shadow-sm uppercase tracking-wider"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Neural Insights</h4>
                  <div className="space-y-3">
                    <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100/50">
                      <div className="flex items-center gap-2 text-indigo-700 font-bold text-[10px] uppercase tracking-wider mb-2">
                        <TrendingUp className="w-3 h-3 text-indigo-500" /> Pattern Detected
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">Fintech sector engagement is up <span className="font-bold text-indigo-700">12%</span> since we automated the regulatory check workflow.</p>
                    </div>
                    <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-100/50">
                      <div className="flex items-center gap-2 text-rose-700 font-bold text-[10px] uppercase tracking-wider mb-2">
                        <AlertCircle className="w-3 h-3 text-rose-500" /> Risk Vector
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed"><span className="font-bold text-rose-700">2 startups</span> have missed their last 2 mentor sessions. Recommendation: Trigger auto-reminder pulse.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-slate-100 bg-white">
                <div className="relative">
                  <textarea 
                    value={copilotInput}
                    onChange={(e) => setCopilotInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleCopilotSend();
                      }
                    }}
                    placeholder="Enter command or query..." 
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-5 pr-14 text-xs font-semibold focus:ring-2 focus:ring-indigo-100 resize-none h-24 transition shadow-inner placeholder:text-slate-400"
                  />
                  <button 
                    onClick={handleCopilotSend}
                    disabled={isCopilotLoading || !copilotInput.trim()}
                    className={cn(
                      "absolute bottom-4 right-4 w-10 h-10 rounded-xl flex items-center justify-center transition shadow-lg",
                      isCopilotLoading || !copilotInput.trim() ? "bg-slate-200 text-slate-400" : "bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/30"
                    )}
                  >
                    {isCopilotLoading ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Zap className="w-5 h-5 fill-current" />
                    )}
                  </button>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {notification && (
          <Notification message={notification.message} type={notification.type} />
        )}
      </AnimatePresence>
    </div>
  );
}
