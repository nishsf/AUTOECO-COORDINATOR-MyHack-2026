import React from 'react';
import { motion } from 'motion/react';
import { BrainCircuit, LogIn, ShieldCheck } from 'lucide-react';
import { useAuth } from '../AuthProvider';

export const Login = () => {
  const { login, loading } = useAuth();
  
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-[120px]" />
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white border border-slate-200 rounded-[2.5rem] shadow-2xl p-10 relative z-10"
      >
        <div className="text-center space-y-6">
          <div className="w-20 h-20 bg-indigo-600 rounded-3xl mx-auto flex items-center justify-center text-white shadow-2xl shadow-indigo-500/20">
            <BrainCircuit className="w-10 h-10" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">AutoEco Control</h1>
            <p className="text-slate-500 font-medium">Ecosystem Coordination Node Authorization</p>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 text-left">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-white rounded-xl border border-slate-200 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Restricted Access</p>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">Please sign in with your authorized Google Account to access the coordinator dashboard.</p>
              </div>
            </div>
          </div>

          <button
            onClick={login}
            disabled={loading}
            className="w-full bg-slate-900 text-white flex items-center justify-center gap-3 py-4 rounded-2xl font-bold text-sm tracking-tight hover:bg-black transition-all shadow-xl shadow-slate-200 group"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <LogIn className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                Authorized Login
              </>
            )}
          </button>
          
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
            Protocol v4.1.0 • AES-256 Encrypted
          </p>
        </div>
      </motion.div>
    </div>
  );
};
