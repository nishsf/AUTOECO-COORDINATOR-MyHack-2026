import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API routes for AI Copilot
app.post("/api/copilot", async (req, res) => {
  try {
    const { message, context } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: "GEMINI_API_KEY is not configured in secrets." });
    }

    const systemInstruction = `
      You are the AutoEco AI Copilot, a strategic ecosystem coordinator.
      Your goal is to help the administrator manage the startup ecosystem effectively.
      
      You have access to the following ecosystem data:
      - Startups: ${JSON.stringify(context.startups)}
      - Mentors: ${JSON.stringify(context.mentors)}
      - Relationships: ${JSON.stringify(context.relationships)}
      
      When answering:
      - Be analytical and professional.
      - Use the data provided to give specific answers.
      - Identify risks (e.g., startups without mentor meetings) or opportunities (e.g., high-potential matches).
      - Keep responses concise and formatted for a chat interface.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: message,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Copilot Error:", error);
    res.status(500).json({ error: error.message || "Failed to generate response" });
  }
});

// Vite middleware for development
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
}

setupVite().then(() => {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});
